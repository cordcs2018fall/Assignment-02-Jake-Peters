package com.company;

/**
 * soda item class
 * @author Jake Peters
 */
public class Soda implements ItemInterface {
    // properties
    private String name;
    private double price;

    // constructors
    public Soda (String name, double price) {
        this.name = name;
        this.price = price;
    }
    // getters and setters
    @Override
    public String getName() {
        return name;
    }
    @Override
    public String setName() {
        this.name = name;
        return null;
    }
    @Override
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    @Override
    public double setPrice() {
        this.price = price;
        return 0;
    }
}