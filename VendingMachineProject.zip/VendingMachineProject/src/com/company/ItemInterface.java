package com.company;

/**
 * interface for the items
 * @author Jake Peters
 * @param <E>
 */
public interface ItemInterface<E> {
    // setters and getters that are implemented from the three vending machines
    public String getName();
    public double getPrice();
    public double setPrice();
    public String setName();


}




