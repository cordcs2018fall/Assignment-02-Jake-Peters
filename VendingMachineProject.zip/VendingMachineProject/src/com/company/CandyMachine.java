package com.company;

import java.util.LinkedList;
import java.util.Queue;


/**
 * vending machine of candy
 * @author Jake Peters
 */
public class CandyMachine implements IVendingMachine{
    double money = 0;
    // creating a queue for each slot in linked list implementation
    Queue<com.company.Candy> slot1 = new LinkedList<>();
    Queue<com.company.Candy> slot2 = new LinkedList<>();
    Queue<com.company.Candy> slot3 = new LinkedList<>();

    // constructs a candy machine with three slots in which items will be removed in a queue structure
    public CandyMachine (Candy firstCandy, int candyNum1,Candy secondCandy,
                         int candyNum2, Candy thirdCandy, int candyNum3){
        for(int i = 0; i < candyNum1; i++) { slot1.add(firstCandy); }
        for(int i = 0; i < candyNum2; i++) { slot2.add(secondCandy); }
        for(int i = 0; i < candyNum3; i++) { slot3.add(thirdCandy);  }
    }
    // accepts money from the user
    @Override
    public void TakeMoney(double amount) {
        money +=amount;
    }
    // gets the price of the item in the slotCode
    @Override
    public boolean compareMoney(String slotCode) {
        double price = 0;
        switch (slotCode)
        {   case "1" : price = slot1.peek().getPrice(); break;
            case "2" : price = slot2.peek().getPrice(); break;
            case "3" : price = slot3.peek().getPrice(); break;
        }
        if(money >= price) {
            return true;
        }  else{ return false;}
    }
    // returns money to the user
    @Override
    public double ReturnMoney() {
        double returnMoney = money;
        return returnMoney;
    }
    // vends candy to the user
    @Override
    public ItemInterface VendItem(String slotCode) {
        Queue<Candy> nowSlot = null;
        // if the slotCode equals 1, 2, or 3, that equals their respective slot in the queue
        switch (slotCode)
        {   case "1" : nowSlot = slot1; break;
            case "2" : nowSlot = slot2; break;
            case "3" : nowSlot = slot3; break;
        }
        money = money - nowSlot.peek().getPrice();
        // removes the chosen item from the vending machine
        return nowSlot.remove();
    }
    // returns the user's chosen candy machine information
    @Override
    public String GetMachineInfo() {
        return "You have chosen a candy machine";
    }
    // displays the contents of the updated vending machine
    @Override
    public String DisplayContents() {
        String result = "";
        result += "1. " + slot1.peek().getName()+ " is $ " + slot1.peek().getPrice() + " with " + slot1.size() + " items left\r\n";
        result += "2. " + slot2.peek().getName()+ " is $ " + slot2.peek().getPrice() + " with " + slot2.size() + " items left\r\n";
        result += "3. " + slot3.peek().getName()+ " is $ " + slot3.peek().getPrice() + " with " + slot3.size() + " items left";
        return result;
    }
}