package com.company;
import java.util.Queue;
import java.util.LinkedList;


import java.util.LinkedList;
import java.util.Queue;

/**
 * vending machine of soda
 * @author Jake Peters
 */
public class SodaMachine implements IVendingMachine{
    double money = 0;
    // creating a queue for each slot in linked list implementation
    Queue<com.company.Soda> slot1 = new LinkedList<>();
    Queue<com.company.Soda> slot2 = new LinkedList<>();
    Queue<com.company.Soda> slot3 = new LinkedList<>();

    // constructs a soda machine with three slots in which items will be removed in a queue structure
    public SodaMachine (Soda firstSoda, int SodaNum1,Soda secondSoda,
                        int SodaNum2, Soda thirdSoda, int SodaNum3){
        for(int i = 0; i < SodaNum1; i++) { slot1.add(firstSoda); }
        for(int i = 0; i < SodaNum2; i++) { slot2.add(secondSoda); }
        for(int i = 0; i < SodaNum3; i++) { slot3.add(thirdSoda);  }
    }
    // accepts money from the user
    @Override
    public void TakeMoney(double amount) {
        money +=amount;
    }
    // gets the price of the item in the slotCode
    @Override
    public boolean compareMoney(String slotCode) {
        double price = 0;
        switch (slotCode)
        {   case "1" : price = slot1.peek().getPrice(); break;
            case "2" : price = slot2.peek().getPrice(); break;
            case "3" : price = slot3.peek().getPrice(); break;
        }
        if(money >= price) {
            return true;
        }  else{ return false;}
    }
    // returns money to the user

    /**
     *
     * @return
     */
    @Override
    public double ReturnMoney() {
        double returnMoney = money;
        money = 0;
        return returnMoney;
    }
    // vends candy to the user
    @Override
    public ItemInterface VendItem(String slotCode) {
        Queue<Soda> nowSlot = null;
        // if the slotCode equals 1, 2, or 3, that equals their respective slot in the queue
        switch (slotCode)
        {   case "1" : nowSlot = slot1; break;
            case "2" : nowSlot = slot2; break;
            case "3" : nowSlot = slot3; break;
        }
        money = money - nowSlot.peek().getPrice();
        // removes the chosen item from the vending machine
        return nowSlot.remove();
    }
    // returns the user's chosen candy machine information
    @Override
    public String GetMachineInfo() {
        return "You have chosen a candy machine";
    }
    // displays the contents of the updated vending machine
    @Override
    public String DisplayContents() {
        String result = "";
        result += "1. " + slot1.peek().getName()+ " is $ " + slot1.peek().getPrice() + " with " + slot1.size() + " items left\r\n";
        result += "2. " + slot2.peek().getName()+ " is $ " + slot2.peek().getPrice() + " with " + slot2.size() + " items left\r\n";
        result += "3. " + slot3.peek().getName()+ " is $ " + slot3.peek().getPrice() + " with " + slot3.size() + " items left";
        return result;
    }
}