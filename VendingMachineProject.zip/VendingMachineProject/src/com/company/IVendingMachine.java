package com.company;

/**
 * taken from the assignment 2 moodle pdf
 * interface for the vending machines
 * @author Jake Peters
 * @param <E>
 */
public interface IVendingMachine<E> {
    //Accepts the amount of money from the user
    public void TakeMoney(double amount);

    //Gets the price of the item in the slotCode
    public boolean compareMoney(String slotCode);

    //Returns the amount of money to the user
    public double ReturnMoney();

    //Spits out an item based on the vending slot chosen by the user
    //Each vending machine should have Slot1, Slot2, and Slot3
    //Up to 3 items can be placed in each slot of the vending machine
    public ItemInterface VendItem(String slotCode);

    //Displays what kind of vending machine it is
    public String GetMachineInfo();

    //Shows the item name and price for each Slot of the machine
    public String DisplayContents();
}





