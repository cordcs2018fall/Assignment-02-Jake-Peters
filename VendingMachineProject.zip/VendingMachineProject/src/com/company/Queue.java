package com.company;

public class Queue {

}
