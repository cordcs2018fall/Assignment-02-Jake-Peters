package com.company;

/*
 * "Jake Peters has created a majestic vending machine" - Jake Peters
 * a big thank you to the tutors! They certainly helped.
 */

import java.util.Scanner;

/**
 * runs the vending machine classes
 * @author Jake Peters
 */
public class VendingMachine {
    public static void main(String[] args) {
        //constructing the CandyMachine items
        Candy Snickers = new Candy("Snickers",1.00);
        Candy MilkyWay = new Candy("MilkyWay", 2.00);
        Candy Reeses = new Candy("Reeses", 3.00);
        //SodaMachine items
        Soda Sprite = new Soda("Sprite", 2.50);
        Soda Coke = new Soda("Coke", 1.50);
        Soda SevenUp = new Soda("SevenUp", 3.00);
        //MixedMachine items
        Mixed Water = new Mixed("Water", .5);
        Mixed Oreos = new Mixed("Oreos", 2.00);
        Mixed Skittles = new Mixed("Skittles", .5);
        // constructing the vending machines
        CandyMachine cm = new CandyMachine(MilkyWay, 5, Reeses, 7, Snickers, 2);
        SodaMachine sm = new SodaMachine(Coke, 3, SevenUp, 5, Sprite, 5);
        MixedMachine mm = new MixedMachine(Skittles, 6, Oreos, 2, Water, 4);
        Scanner input = new Scanner(System.in);
        IVendingMachine activeMachine = null;
        System.out.println("Hello, you are buying from Peters LLC");
        // loops through the vending machine
        // the user picks a valid value, otherwise they exit the program
        while(true) {
            System.out.println("Please choose a vending machine: C for Candy, S for Soda, or M for Mixed or Q to quit");
            String userChoice = input.nextLine();
            if (userChoice.equalsIgnoreCase("C")) {
                activeMachine = cm;
                System.out.println("You chose the Candy Machine");
            } else if (userChoice.equalsIgnoreCase("S")) {
                activeMachine = sm;
                System.out.println("You chose the Soda Machine");
            } else if (userChoice.equalsIgnoreCase("M")) {
                activeMachine = mm;
                System.out.println("You chose the Mixed Machine");
            } else if (userChoice.equalsIgnoreCase("Q")) {
                System.out.println(" Say goodbye to Peters LLC. Bye-Bye");
                return;
            } else {
                System.out.println("please input a correct value");
            }
            // slotCode is from 1 to 3, and this along with the user determines which item is vended
            boolean valid = false;
            String slotCode = "";
            while(!valid) {
                System.out.println(activeMachine.DisplayContents());
                System.out.println("Please choose item 1, 2, or 3");
                slotCode = input.nextLine();
                if(slotCode.equals("1")|| slotCode.equals("2")|| slotCode.equals("3")) { valid = true; }
                else {System.out.println("Sorry that is not a correct value. Please type 1, 2, or 3");}
            }
            System.out.println("Please insert the correct amount of money");
            String money = null;
            double dollarValue=0;
            valid = false;
            boolean goodMoney = false;
            // while loop is to check if the user inputs the right amount of money
            while (!goodMoney) {
                money = input.nextLine();
                while(!valid){
                    //this try catch makes sure the user inputs money
                    try {
                        dollarValue = Double.parseDouble(money);
                        valid=true;
                    } catch(Exception e) {
                        System.out.println("Please give money");
                        money = input.nextLine();
                    }
                }
                //the computer compares the money given to money needed
                activeMachine.TakeMoney(dollarValue);
                goodMoney = activeMachine.compareMoney(slotCode);
                if (!goodMoney) { System.out.println("more money is necessary to get your treat"); }
            }
            //the item is given to the user along with the change amount
            System.out.println("Here is your change: $" + (dollarValue-activeMachine.VendItem(slotCode).getPrice()));
            System.out.println("Here is your new, tasty " + activeMachine.VendItem(slotCode).getName());

        }
    }
}