package com.company;
/**
 * soda and candy items mixed
 * @author Jake Peters
 */
public class Mixed implements ItemInterface {
    //properties
    private String name;
    private double price;
    //constructors
    public Mixed(String name, double price) {
        this.name = name;
        this.price = price;
    }
    //getters and setters
    @Override
    public String getName() {
        return name;
    }
    @Override
    public String setName() {
        this.name = name;
        return null;
    }
    @Override
    public double getPrice() {
        return price;
    }
    @Override
    public double setPrice() {
        this.price = price;
        return 0;
    }
}


